"""Conversation tree helpers (ChatGPT-style message branching)."""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional

from weakagent.memory.message import Message


def index_messages_by_id(messages: Iterable[Message]) -> Dict[str, Message]:
    out: Dict[str, Message] = {}
    for msg in messages:
        if msg.id:
            out[str(msg.id)] = msg
    return out


def resolve_branch_path(
    messages: List[Message],
    leaf_id: Optional[str],
) -> List[Message]:
    """Return root→leaf path. Falls back to full linear list when branching is absent."""
    by_id = index_messages_by_id(messages)
    if not leaf_id or leaf_id not in by_id:
        # Legacy / no leaf: keep insertion order (already sorted by callers).
        return list(messages)

    path: List[Message] = []
    cur: Optional[str] = leaf_id
    seen: set[str] = set()
    while cur and cur not in seen:
        seen.add(cur)
        msg = by_id.get(cur)
        if msg is None:
            break
        path.append(msg)
        cur = msg.parent_id
    path.reverse()
    return path if path else list(messages)


def list_children(messages: List[Message], parent_id: Optional[str]) -> List[Message]:
    """Messages whose parent_id equals ``parent_id`` (siblings / versions)."""
    return [m for m in messages if (m.parent_id or None) == (parent_id or None)]


def find_last_user(messages: List[Message]) -> Optional[Message]:
    for msg in reversed(messages):
        if msg.role == "user":
            return msg
    return None


def find_parent_user(messages: List[Message], message_id: str) -> Optional[Message]:
    """Walk up from ``message_id`` until a user message is found (inclusive)."""
    by_id = index_messages_by_id(messages)
    cur = by_id.get(message_id)
    seen: set[str] = set()
    while cur is not None and cur.id and cur.id not in seen:
        seen.add(cur.id)
        if cur.role == "user":
            return cur
        if not cur.parent_id:
            break
        cur = by_id.get(cur.parent_id)
    return None
