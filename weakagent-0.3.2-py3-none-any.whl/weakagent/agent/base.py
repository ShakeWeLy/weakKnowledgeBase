from abc import ABC, abstractmethod
import asyncio
from contextlib import asynccontextmanager
import inspect
import threading
import time
import uuid
from typing import Any, Awaitable, Callable, Dict, List, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, model_validator

from weakagent.llm import LLM
from weakagent.utils.logger import get_logger
from weakagent.schemas.message import ROLE_TYPE, Message, Role
from weakagent.memory.conversation import ConversationMemory
from weakagent.memory.short import ShortMemory
from weakagent.memory.long import LongMemory
from weakagent.memory.working import WorkingMemory
from weakagent.memory.session import SessionMemory, SessionMemorySummaryEntry
from weakagent.schemas.agent import AgentState

logger = get_logger(__name__)

EventCallback = Callable[[dict], Union[Any, Awaitable[Any]]]


class BaseAgent(BaseModel, ABC):
    """Abstract base class for managing agent state and execution.

    Provides foundational functionality for state transitions, memory management,
    and a step-based execution loop. Subclasses must implement the `step` method.
    """
    # Agent dependencies such as LLM and memory stores are runtime objects, not
    # Pydantic data models; allow them to pass through validation unchanged.
    model_config = ConfigDict(arbitrary_types_allowed=True)

    # Core attributes
    name: str = Field(..., description="Unique name of the agent")
    description: Optional[str] = Field(None, description="Optional agent description")

    # Prompts
    system_prompt: Optional[str] = Field(
        None, description="System-level instruction prompt"
    )
    system_messages: List[Message] = Field(
        default_factory=list, description="System messages for the agent"
    )
    next_step_prompt: Optional[str] = Field(
        None, description="Prompt for determining next action"
    )

    # Dependencies
    llm: LLM = Field(default_factory=LLM, description="Language model instance")

    # Execution control
    max_steps: int = Field(default=10, description="Maximum steps before termination")
    current_step: int = Field(default=0, description="Current step in execution")
    duplicate_threshold: int = 2
    on_event: Optional[EventCallback] = Field(
        default=None, description="Optional event callback for agent lifecycle events"
    )
    state: AgentState = Field(
        default=AgentState.IDLE, description="Current agent state"
    )
    awaiting_human: bool = Field(
        default=False,
        description="If true, this run is paused awaiting user input; do not persist last_result.",
    )

    # Memory
    working_memory: WorkingMemory = Field(
        default_factory=WorkingMemory, description="Per-run agent working context"
    )
    short_memory: ShortMemory = Field(
        default_factory=ShortMemory, description="Per-run agent working context with history"
    )
    conversation: Optional[ConversationMemory] = Field(
        default=None,
        description="Append-only per-message persistence",
    )
    session: Optional[SessionMemory] = Field(
        default=None,
        description="Session metadata and end-of-loop summary",
    )
    long_memory: Optional[LongMemory] = Field(
        default=None,
        description="Long-term user memory formatted for system prompt injection",
    )

    # IDs
    user_id: Optional[str] = Field(
        default=None,
        description="User id for the agent",
    )
    run_id: Optional[str] = Field(
        default_factory=lambda: uuid.uuid4().hex[:12],
        description="Run id for the agent",
    )
    session_id: Optional[str] = Field(
        default_factory=lambda: uuid.uuid4().hex[:12],
        description="Session id for the agent",
    )
    agent_id: Optional[str] = Field(
        default_factory=lambda: uuid.uuid4().hex[:12],
        description="Agent id for the agent",
    )

    # Request and Response
    request: Optional[str] = Field(default=None, description="Current request from user")
    last_request: Optional[str] = Field(default=None)
    last_result: Optional[str] = Field(default=None)

    # Optional
    only_last_result: bool = Field(default="", description="If only return last output result from agent")
    summarize_short_memory: bool = Field(default=False, description="If return the summarize of the short memory")
    summarize_working_memory: bool = Field(default=False, description="If summarize the working memory to enable SKILLS_USAGE_PROMPT")
    verbose: bool = Field(default=False, description="If verbose the agent execution, llm input and output")
    use_long_memory: bool = Field(default=False, description="If use long-term memory, add to system message")
    only_save_last_result_to_short: bool = Field(default=False, description="If only save the last result to the short memory")
    skills_enabled: bool = Field(
        default=True, description="Inject <available_skills> into system prompts"
    )
    skill_filter: Optional[List[str]] = Field(
        default=None, description="Optional allow-list of skill names"
    )
    _system_messages_persisted_session: Optional[str] = PrivateAttr(default=None)
    _pending_recovery_request: Optional[str] = PrivateAttr(default=None)
    _last_recovery_fingerprint: Optional[str] = PrivateAttr(default=None)
    _recovery_attempt_count: int = PrivateAttr(default=0)
    _branch_parent_run_id: Optional[str] = PrivateAttr(default=None)

    def reset_recovery_budget(self) -> None:
        """Clear recovery dedupe state (call when the user sends a fresh request)."""
        self._last_recovery_fingerprint = None
        self._recovery_attempt_count = 0

    def schedule_recovery_request(self, error_text: str) -> bool:
        """Queue auto-recovery user message if budget allows.

        Returns:
            True if a recovery turn was scheduled; False when the same error
            fingerprint already exhausted MAX_RECOVERY_PER_FINGERPRINT attempts.
        """
        from weakagent.utils.run_errors import (
            MAX_RECOVERY_PER_FINGERPRINT,
            build_recovery_request,
            error_fingerprint,
        )

        fp = error_fingerprint(error_text)
        if fp != self._last_recovery_fingerprint:
            self._last_recovery_fingerprint = fp
            self._recovery_attempt_count = 0
        self._recovery_attempt_count += 1
        if self._recovery_attempt_count > MAX_RECOVERY_PER_FINGERPRINT:
            logger.warning(
                "Recovery budget exhausted for agent %s (fingerprint=%s, attempts=%s)",
                self.name,
                fp,
                self._recovery_attempt_count - 1,
            )
            return False
        self._pending_recovery_request = build_recovery_request(error_text)
        return True

    def pop_recovery_request(self) -> Optional[str]:
        """Return and clear a pending recovery user message, if any."""
        req = self._pending_recovery_request
        self._pending_recovery_request = None
        return req

    @model_validator(mode="after")
    def initialize_agent(self) -> "BaseAgent":
        """Initialize agent with default settings if not provided."""
        try:
            if self.llm is None or not isinstance(self.llm, LLM):
                self.llm = LLM(config_name=self.name.lower())
            if not isinstance(self.short_memory, ShortMemory):
                self.short_memory = ShortMemory(
                    run_id=self.run_id,
                    user_id=self.user_id,
                    agent_type=self.name,
                    agent_id=self.agent_id,
                    session_id=self.session_id,

                )
            if self.session is None or not isinstance(self.session, SessionMemory):
                self.session = SessionMemory(
                    run_id=self.run_id,
                    user_id=self.user_id,
                    agent_type=self.name,
                    agent_id=self.agent_id,
                    session_id=self.session_id,

                )
            if self.conversation is None:
                self.conversation = ConversationMemory(
                    run_id=self.run_id,
                    user_id=self.user_id,
                    agent_type=self.name,
                    agent_id=self.agent_id,
                    session_id=self.session_id,
                    )

            self.system_messages = []
            if self.system_prompt:
                self.system_messages.append(Message.system_message(self.system_prompt))

            if self.use_long_memory:
                if self.long_memory is None:
                    self.long_memory = LongMemory(user_id=self.user_id)
                else:
                    self.long_memory.user_id = self.user_id
                self.long_memory.load_for_user(self.user_id)
                ctx = self.long_memory.to_system_context()
                if ctx:
                    self.system_messages.append(self.long_memory.message)

            # add skills prompt
            if self.skills_enabled:
                mgr = self.get_skill_manager()
                block = mgr.build_skills_prompt(skill_filter=self.skill_filter)
                if block.strip():
                    self.system_messages.append(Message.system_message(block))

            return self
        except Exception:
            logger.exception("Failed to initialize agent")
            return self

    def get_skill_manager(self):
        """Lazy-init SkillManager (not a pydantic field to avoid deep copy issues)."""
        mgr = getattr(self, "_skill_manager", None)
        if mgr is None:
            from weakagent.skills.manager import SkillManager

            mgr = SkillManager()
            object.__setattr__(self, "_skill_manager", mgr)
        return mgr

    def _emit_event(self, event_type: str, data: Optional[dict] = None) -> None:
        """Emit an event to callbacks (sync/async; isolated failures).

        Delivery order:
        1) self.on_event (if set)
        2) runtime.on_event (if agent is runtime-managed and runtime exposes on_event)
        """

        event = {
            "type": event_type,
            "timestamp": time.time(),
            "data": data or {},
        }

        def _dispatch(cb: Any) -> None:
            if cb is None:
                return
            try:
                result = cb(event)
                if inspect.isawaitable(result):
                    task = asyncio.create_task(result)

                    def _on_done(t: asyncio.Task) -> None:
                        try:
                            exc = t.exception()
                        except asyncio.CancelledError:
                            return
                        except Exception:
                            logger.exception(
                                "Unexpected error while checking on_event task"
                            )
                            return
                        if exc is not None:
                            logger.exception("on_event async callback failed", exc_info=exc)

                    task.add_done_callback(_on_done)
            except Exception as e:
                logger.error(f"Event callback error: {e}")

        _dispatch(self.on_event)

        runtime = getattr(self, "agent_runtime", None)
        runtime_cb = getattr(runtime, "on_event", None) if runtime is not None else None
        if runtime_cb is not self.on_event:
            _dispatch(runtime_cb)

    def _persist_system_messages(self) -> None:
        """Persist agent system_messages to conversation DB once per session.

        Uses an in-memory flag only (no DB read). Same session_id within one agent
        instance writes at most once; subsequent ``run()`` calls return immediately.
        """
        if not self.system_messages or self.conversation is None:
            return

        session_id = self.session.session_id if self.session is not None else self.session_id
        if not session_id:
            return
        if self._system_messages_persisted_session == session_id:
            return

        conv = self.conversation
        conv.session_id = session_id
        if self.run_id:
            conv.run_id = self.run_id
        if self.user_id:
            conv.user_id = self.user_id
        if self.session is not None:
            conv.agent_id = conv.agent_id or self.session.agent_id
            conv.agent_type = conv.agent_type or self.session.agent_type

        extra = {
            "agent": self.name,
            "kind": "system_prompt",
        }
        try:
            for msg in self.system_messages:
                conv._persist_message(msg, extra=extra)
            self._system_messages_persisted_session = session_id
        except Exception:
            logger.exception("Failed to persist system messages for session_id=%s", session_id)

    def current_leaf_id(self) -> Optional[str]:
        """Active branch tip: session.active_leaf_id or last short_memory message id."""
        if self.session is not None and self.session.active_leaf_id:
            return self.session.active_leaf_id
        for msg in reversed(self.short_memory.messages):
            if msg.id:
                return msg.id
        return None

    def append_message(self, message: Message, *, extra: Optional[Dict[str, Any]] = None) -> None:
        """Append to short memory, conversation log, and in-memory session transcript."""
        import uuid as _uuid

        if not message.id:
            message.id = f"cmsg_{_uuid.uuid4().hex[:16]}"
        if message.parent_id is None:
            message.parent_id = self.current_leaf_id()
        if message.run_id is None and self.run_id:
            message.run_id = self.run_id
        if message.parent_run_id is None and self._branch_parent_run_id:
            message.parent_run_id = self._branch_parent_run_id

        self.working_memory.add_message(message)
        self.short_memory.add_message(message)
        persist_extra = {
            "agent": self.name,
            "state": str(self.state),
            "current_step": self.current_step,
        }
        if extra:
            persist_extra.update(extra)
        if self.conversation is not None:
            if self.run_id:
                self.conversation.run_id = self.run_id
            self.conversation.parent_run_id = self._branch_parent_run_id
            self.conversation.add_message(message, extra=persist_extra)
        if self.session is not None:
            self.session.messages.append(message)
            try:
                self.session.set_active_leaf(message.id, run_id=self.run_id)
            except Exception:
                logger.exception("Failed to update active_leaf_id")
                self.session.active_leaf_id = message.id
                self.session.active_run_id = self.run_id

        self._emit_event(
            "agent_message_persisted",
            {
                "id": message.id,
                "role": str(message.role),
                "parent_id": message.parent_id,
                "run_id": message.run_id,
                "parent_run_id": message.parent_run_id,
            },
        )

    @asynccontextmanager
    async def state_context(self, new_state: AgentState):
        """Context manager for safe agent state transitions.

        Args:
            new_state: The state to transition to during the context.

        Yields:
            None: Allows execution within the new state.

        Raises:
            ValueError: If the new_state is invalid.
        """
        if not isinstance(new_state, AgentState):
            raise ValueError(f"Invalid state: {new_state}")

        previous_state = self.state
        self.state = new_state
        try:
            yield
        except Exception as e:
            self.state = AgentState.ERROR  # Transition to ERROR on failure
            raise e
        finally:
            self.state = previous_state  # Revert to previous state

    def update_memory(
        self,
        role: ROLE_TYPE,  # type: ignore
        content: str,
        base64_image: Optional[str] = None,
        **kwargs,
    ) -> None:
        """Add a message to the agent's memory.

        Args:
            role: The role of the message sender (user, system, assistant, tool).
            content: The message content.
            base64_image: Optional base64 encoded image.
            **kwargs: Additional arguments (e.g., tool_call_id for tool messages).

        Raises:
            ValueError: If the role is unsupported.
        """
        message_map = {
            "user": Message.user_message,
            "system": Message.system_message,
            "assistant": Message.assistant_message,
            "tool": lambda content, **kw: Message.tool_message(content, **kw),
        }

        if role not in message_map:
            raise ValueError(f"Unsupported message role: {role}")

        # Create message with appropriate parameters based on role
        call_kw: Dict[str, Any] = {"base64_image": base64_image}
        if role == "tool":
            call_kw.update(kwargs)
        elif role == "assistant" and "reasoning_content" in kwargs:
            call_kw["reasoning_content"] = kwargs["reasoning_content"]
        message = message_map[role](content, **call_kw)
        self.append_message(message)
        self._emit_event(
            "agent_memory_add",
            {
                "role": role,
                "content_len": len(content or ""),
                "has_image": bool(base64_image),
            },
        )

    async def run(
        self,
        request: Optional[str] = None,
        *,
        only_save_last_result_to_short: Optional[bool] = None,
        reuse_last_user: bool = False,
        parent_run_id: Optional[str] = None,
    ) -> str:
        """Execute the agent's main loop asynchronously.

        Args:
            request: Optional initial user request to process.
            reuse_last_user: If True, do not append another user message — used by
                regenerate / edit-user flows where the user turn is already in memory.
            parent_run_id: Optional prior run id this run branches from.

        Returns:
            A string summarizing the execution results.

        Raises:
            RuntimeError: If the agent is not in IDLE state at start.
        """
        if self.state != AgentState.IDLE:
            raise RuntimeError(f"Cannot run agent from state: {self.state}")
        if only_save_last_result_to_short is not None:
            self.only_save_last_result_to_short = only_save_last_result_to_short

        # reset run_id, keep run_id for awaiting_human
        if not self.awaiting_human:
            self.run_id = uuid.uuid4().hex[:12]
            self.short_memory.run_id = self.run_id
            self.short_memory.flushed_this_run = False
            self.current_step = 0
            self.state = AgentState.IDLE
            # In-memory once-per-session guard; no DB read on later runs.
            self._persist_system_messages()
        self._branch_parent_run_id = parent_run_id

        # Prune leftover short_memory before a new run (multi-turn runtime loops).
        if self.short_memory.messages and not reuse_last_user:
            try:
                if await self.short_memory.prune(llm=self.llm):
                    logger.info(
                        "Short memory pruned before run (messages=%s strategy=%s)",
                        len(self.short_memory.messages),
                        self.short_memory.cleanup_strategy.value,
                    )
            except Exception as exc:
                logger.warning("Short memory prune before run failed: %s", exc)

        if reuse_last_user:
            last_user = None
            for msg in reversed(self.short_memory.messages):
                if msg.role == "user":
                    last_user = msg
                    break
            if last_user is None:
                raise RuntimeError("reuse_last_user=True but no user message in short_memory")
            self.request = request if request is not None else (last_user.content or "")
            # Keep active leaf on the user so new assistant versions share parent_id=user.id
            if last_user.id and self.session is not None:
                try:
                    self.session.set_active_leaf(last_user.id, run_id=self.run_id)
                except Exception:
                    self.session.active_leaf_id = last_user.id
        else:
            self.request = request
            # record request immediately.
            if self.request is None:
                raise ValueError("request is required when reuse_last_user=False")
            self.update_memory("user", self.request)

        self.working_memory.clear_without_system_messages()

        # New run begins; if we were previously paused, we are now resuming.
        self.awaiting_human = False
        self.last_request = self.request
        self.last_result = None

        results: List[str] = []
        output: Optional[str] = None
        self._emit_event(
            "agent_run_start",
            {
                "name": self.name,
                "max_steps": self.max_steps,
                "request_len": len(self.request or ""),
                "run_id": self.run_id,
                "reuse_last_user": reuse_last_user,
                "parent_run_id": parent_run_id,
            },
        )
        try:
            async with self.state_context(AgentState.RUNNING):
                while (
                    self.current_step < self.max_steps and self.state != AgentState.FINISHED
                ):
                    self.current_step += 1
                    logger.info(f"Executing step {self.current_step}/{self.max_steps}")
                    self._emit_event(
                        "agent_step_start",
                        {
                            "name": self.name,
                            "current_step": self.current_step,
                            "max_steps": self.max_steps,
                        },
                    )

                    # Memory flush: evict oldest messages to sqlite when over limit.
                    try:
                        result = self.short_memory.flush(run_id=self.run_id)
                        if result.flushed:
                            logger.info(
                                "Short memory flushed run_id=%s flushed=%s kept=%s",
                                self.run_id,
                                result.flushed_count,
                                result.kept_count,
                            )
                    except Exception as e:
                        logger.warning("Short memory flush failed: %s", e)

                    step_result = await self.step()
                    # Agents like ToolCallAgent set last_result inside act(); ChatAgent
                    # (and others) only return step text — fill last_result if still empty.
                    if step_result and not self.last_result:
                        self.last_result = step_result
                    self._emit_event(
                        "agent_step_end",
                        {
                            "name": self.name,
                            "current_step": self.current_step,
                            "max_steps": self.max_steps,
                            "result_len": len(step_result or ""),
                        },
                    )

                    # Check for stuck state
                    if self.is_stuck():
                        self.handle_stuck_state()

                    results.append(f"Step {self.current_step}: {step_result}")

                if self.current_step >= self.max_steps:
                    self.current_step = 0
                    self.state = AgentState.IDLE
                    results.append(
                        f"Terminated: Reached max steps ({self.max_steps})"
                    )
            # self.last_result = step_result if step_result else "No last result as output"
            output = "\n".join(results) if results else "No steps executed"

            self._emit_event(
                "agent_run_end",
                {
                    "name": self.name,
                    "current_step": self.current_step,
                    "state": str(self.state),
                    "output_len": len(output),
                    "run_id": self.run_id,
                },
            )

            # Select the last result from the short memory
            if self.summarize_short_memory:
                from weakagent.llm.summarize import summarize_short_memory as _summarize_short
                summary_msg = await _summarize_short(
                    self.llm, list(self.short_memory.messages)
                )
                output = summary_msg.content or ""
                return output
            if self.only_last_result:
                return self.last_result or ""
            return output
        
        finally:
            self._branch_parent_run_id = None
            # Snapshot: merge flushed segments + RAM, or save full short_memory.
            try:
                self.short_memory.finalize_run_memory(run_id=self.run_id)
            except Exception:
                logger.exception("Short memory finalize failed")

            try:
                if not self.awaiting_human:
                    if self.only_save_last_result_to_short:
                        self.short_memory.clear_unitl_last_user_message()
                        self.short_memory.add_message(Message.assistant_message(output))

                    if self.summarize_working_memory:
                        threading.Thread(
                            target=self.working_memory.summarize_and_save_sync,
                            kwargs={"run_id": self.run_id},
                            daemon=True,
                        ).start()

            except Exception:
                logger.exception("Failed after run")

    @abstractmethod
    async def step(self) -> str:
        """Execute a single step in the agent's workflow.

        Must be implemented by subclasses to define specific behavior.
        """

    def handle_stuck_state(self):
        """Handle stuck state by adding a prompt to change strategy"""
        stuck_prompt = "\
        Observed duplicate responses. Consider new strategies and avoid repeating ineffective paths already attempted."
        self.next_step_prompt = f"{stuck_prompt}\n{self.next_step_prompt}"
        logger.warning(f"Agent detected stuck state. Added prompt: {stuck_prompt}")

    def is_stuck(self) -> bool:
        """Check if the agent is stuck in a loop by detecting duplicate content"""
        if len(self.short_memory.messages) < 2:
            return False

        last_message = self.short_memory.messages[-1]
        if not last_message.content:
            return False

        # Count identical content occurrences
        duplicate_count = sum(
            1
            for msg in reversed(self.short_memory.messages[:-1])
            if msg.role == "assistant" and msg.content == last_message.content
        )

        return duplicate_count >= self.duplicate_threshold

    @property
    def messages(self) -> List[Message]:
        """Retrieve a list of messages from the agent's memory."""
        return self.short_memory.messages

    @messages.setter
    def messages(self, value: List[Message]):
        """Set the list of messages in the agent's memory."""
        self.short_memory.messages = value
