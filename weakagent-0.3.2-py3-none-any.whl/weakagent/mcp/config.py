"""Load MCP server definitions from config.toml."""

from __future__ import annotations
from dataclasses import dataclass, field
import os
from typing import Any, Dict, List, Optional

from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from weakagent.config.settings import config


@dataclass
class MCPServerSpec:
    """One MCP server connection."""

    id: str
    description: str = ""
    available: bool = True
    transport: str = "streamable_http"  # streamable_http | sse | stdio
    url: Optional[str] = None
    command: Optional[str] = None
    args: List[str] = field(default_factory=list)
    headers: Dict[str, str] = field(default_factory=dict)
    sync_key: Optional[str] = None
    enabled: bool = True

    def resolved_url(self) -> str:
        """Build URL with sync_key query param when configured."""
        if not self.url:
            raise ValueError(f"MCP server '{self.id}' has no url")
        if not self.sync_key:
            return self.url
        parsed = urlparse(self.url)
        query = dict(parse_qsl(parsed.query, keep_blank_values=True))
        query.setdefault("sync_key", self.sync_key)
        return urlunparse(parsed._replace(query=urlencode(query)))

    def resolved_headers(self) -> Dict[str, str]:
        """Merge custom headers with X-Sync-Key when sync_key is set."""
        out = dict(self.headers)
        if self.sync_key and "X-Sync-Key" not in out and "x-sync-key" not in out:
            out["X-Sync-Key"] = self.sync_key
        return out


@dataclass
class MCPSettings:
    enabled: bool = False
    servers: List[MCPServerSpec] = field(default_factory=list)


def _env_enabled(enabled: bool) -> bool:
    """Allow MCP_ENABLED to override the configured global switch."""
    raw = os.getenv("MCP_ENABLED")
    if raw is None:
        return enabled
    return raw.strip().lower() in {"1", "true", "yes", "on", "enabled"}


def _mcp_settings_from_section(section: Dict[str, Any]) -> MCPSettings:
    if not isinstance(section, dict):
        return MCPSettings()

    servers: List[MCPServerSpec] = []

    configured_services = section.get("services")
    if configured_services is None:
        configured_services = section.get("servers")
    if isinstance(configured_services, dict):
        configured_services = [
            {**value, "id": key}
            for key, value in configured_services.items()
            if isinstance(value, dict)
        ]
    for item in configured_services or []:
        if isinstance(item, dict):
            servers.append(_spec_from_dict(item))

    if not servers and (section.get("server_url") or section.get("url")):
        servers.append(
            MCPServerSpec(
                id=str(section.get("server_id") or section.get("id") or "default"),
                description=str(section.get("description") or ""),
                available=bool(section.get("available", True)),
                transport=str(section.get("transport") or "streamable_http"),
                url=section.get("server_url") or section.get("url"),
                sync_key=section.get("sync_key"),
                headers=_as_str_dict(section.get("headers")),
                enabled=True,
            )
        )

    has_servers = bool(servers)
    enabled = _env_enabled(bool(section.get("enabled", False)) or has_servers)
    return MCPSettings(enabled=enabled, servers=[s for s in servers if s.enabled])


def load_mcp_settings(config_path: Optional[str] = None) -> MCPSettings:
    """Parse [mcp] from global config, or an alternate TOML path when given."""
    if config_path is None:
        return _mcp_settings_from_section(config.mcp_raw)

    path = config.resolve_path(config_path)
    if not path.exists():
        return MCPSettings()
    try:
        import tomllib
    except ModuleNotFoundError:
        import tomli as tomllib  # type: ignore[no-redef]
    raw = tomllib.loads(path.read_text(encoding="utf-8"))
    section = raw.get("mcp") or {}
    return _mcp_settings_from_section(section)


def _spec_from_dict(data: Dict[str, Any]) -> MCPServerSpec:
    return MCPServerSpec(
        id=str(data.get("id") or data.get("server_id") or "mcp"),
        description=str(data.get("description") or ""),
        available=bool(data.get("available", True)),
        transport=str(data.get("transport") or "streamable_http"),
        url=data.get("url") or data.get("server_url"),
        command=data.get("command"),
        args=[str(a) for a in (data.get("args") or [])],
        headers=_as_str_dict(data.get("headers")),
        sync_key=data.get("sync_key"),
        enabled=bool(data.get("enabled", True)),
    )


def _as_str_dict(value: Any) -> Dict[str, str]:
    if not isinstance(value, dict):
        return {}
    return {str(k): str(v) for k, v in value.items()}


def load_available_mcp_services(
    services: Optional[List[MCPServerSpec]] = None,
    *,
    load_env_enabled: bool = True,
    available_only: bool = True,
) -> List[MCPServerSpec]:
    """Return enabled MCP service specifications without opening connections.

    Args:
        services: Optional in-memory specifications. When omitted, ``config.toml``
            is loaded so callers can inject demo or test services directly.
        load_env_enabled: Whether ``MCP_ENABLED`` may disable all services.
        available_only: Whether to hide services with ``available = false``.

    Returns:
        Enabled service specifications. Credentials are retained internally for
        connection setup but should not be exposed by listing tools.
    """
    if services is None:
        settings = load_mcp_settings()
        candidates = settings.servers if settings.enabled else []
    else:
        if load_env_enabled and not _env_enabled(True):
            return []
        candidates = [service for service in services if service.enabled]
    if available_only:
        candidates = [service for service in candidates if service.available]
    return list(candidates)
