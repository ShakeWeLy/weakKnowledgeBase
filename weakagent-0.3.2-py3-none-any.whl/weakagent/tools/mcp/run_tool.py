"""Tool for invoking a selected remote MCP tool."""

from __future__ import annotations

from typing import Any, Dict, Optional

from weakagent.tools.base import BaseTool, ToolExecutionResult
from weakagent.tools.mcp.context import MCPToolContext


class RunMCPTool(BaseTool):
    """Run one named tool from one configured MCP service."""

    name = "run_mcp_tool"
    description = (
        "Run a tool exposed by an MCP service. Use list_mcp_tools first to "
        "discover the exact tool name and arguments."
    )
    parameters = {
        "type": "object",
        "properties": {
            "service_id": {
                "type": "string",
                "description": "Configured MCP service id.",
            },
            "tool_name": {
                "type": "string",
                "description": "Original remote MCP tool name.",
            },
            "arguments": {
                "type": "object",
                "description": "Arguments required by the remote MCP tool.",
            },
        },
        "required": ["service_id", "tool_name"],
    }

    def __init__(self, context: MCPToolContext) -> None:
        self.context = context

    async def execute(
        self,
        service_id: str,
        tool_name: str,
        arguments: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> ToolExecutionResult:
        try:
            clients = await self.context.connect(service_id)
            target = next(
                (
                    tool
                    for tool in clients.tools
                    if tool.server_id == service_id
                    and tool.original_name == tool_name
                ),
                None,
            )
            if target is None:
                return self.fail_response(
                    f"MCP tool not found: service_id={service_id}, tool_name={tool_name}"
                )
            return await target.execute(**(arguments or {}))
        except Exception as exc:
            return self.fail_response(f"Failed to run MCP tool: {exc}")

    async def cleanup(self) -> None:
        """Close connections owned by the shared MCP context."""
        await self.context.close()

