"""Tool for listing configured MCP service metadata."""

from __future__ import annotations

from typing import Any

from weakagent.tools.base import BaseTool, ToolExecutionResult
from weakagent.tools.mcp.context import MCPToolContext


class GetAvailableMCPServicesTool(BaseTool):
    """Return safe metadata for enabled MCP services without connecting."""

    name = "get_available_mcp_services"
    description = (
        "List enabled MCP services with their id, description, transport, and endpoint."
    )
    parameters = {"type": "object", "properties": {}}

    def __init__(self, context: MCPToolContext) -> None:
        self.context = context

    async def execute(self, **kwargs: Any) -> ToolExecutionResult:
        services = [
            {
                "id": service.id,
                "description": service.description,
                "transport": service.transport,
                "url": service.url or "",
                "enabled": service.enabled,
            }
            for service in self.context.services
            if service.available
        ]
        return self.success_response({"services": services})

