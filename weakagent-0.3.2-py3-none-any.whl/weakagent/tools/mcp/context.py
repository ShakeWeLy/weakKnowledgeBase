"""Shared lazy MCP connection context for Agent-facing tools."""

from __future__ import annotations

from typing import Dict, List, Optional

from weakagent.mcp.client import MCPClients
from weakagent.mcp.config import MCPServerSpec, load_available_mcp_services


class MCPToolContext:
    """Resolve services first and connect each service only when requested."""

    def __init__(self, services: Optional[List[MCPServerSpec]] = None) -> None:
        self.services = load_available_mcp_services(services, available_only=False)
        self.clients = MCPClients()
        self._connected: Dict[str, MCPServerSpec] = {}

    def find_service(self, service_id: str) -> Optional[MCPServerSpec]:
        """Find a configured service by its stable ID."""
        return next((s for s in self.services if s.id == service_id), None)

    async def connect(self, service_id: str) -> MCPClients:
        """Connect one service on demand and return the shared client collection."""
        if self.find_service(service_id) is None:
            raise ValueError(f"MCP service not found: {service_id}")
        if service_id not in self._connected:
            spec = self.find_service(service_id)
            assert spec is not None
            await self.clients.connect_spec(spec)
            self._connected[service_id] = spec
        return self.clients

    async def close(self) -> None:
        """Close all MCP sessions created by this context."""
        await self.clients.disconnect()
        self._connected.clear()
