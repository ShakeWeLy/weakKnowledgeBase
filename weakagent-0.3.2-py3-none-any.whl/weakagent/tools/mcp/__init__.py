"""Agent-facing MCP discovery and execution tools."""

from weakagent.mcp import MCPClients, create_mcp_clients_from_config, load_mcp_settings
from weakagent.tools.mcp.context import MCPToolContext
from weakagent.tools.mcp.list_tools import ListMCPToolsTool
from weakagent.tools.mcp.run_tool import RunMCPTool
from weakagent.tools.mcp.services import GetAvailableMCPServicesTool


def create_mcp_tools(services=None) -> list:
    """Create the three MCP Agent tools sharing one lazy connection context."""
    context = MCPToolContext(services)
    return [
        GetAvailableMCPServicesTool(context),
        ListMCPToolsTool(context),
        RunMCPTool(context),
    ]


__all__ = [
    "MCPClients",
    "create_mcp_clients_from_config",
    "load_mcp_settings",
    "MCPToolContext",
    "create_mcp_tools",
    "GetAvailableMCPServicesTool",
    "ListMCPToolsTool",
    "RunMCPTool",
]
