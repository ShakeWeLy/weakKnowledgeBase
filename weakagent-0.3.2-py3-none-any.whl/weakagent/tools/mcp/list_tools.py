"""Tool for discovering tools exposed by MCP services."""

from __future__ import annotations

from typing import Any, Optional

from weakagent.tools.base import BaseTool, ToolExecutionResult
from weakagent.tools.mcp.context import MCPToolContext


class ListMCPToolsTool(BaseTool):
    """List remote tools for one service or for every available service."""

    name = "list_mcp_tools"
    description = (
        "List tools exposed by an MCP service. Optionally provide service_id; "
        "call get_available_mcp_services first when multiple services exist."
    )
    parameters = {
        "type": "object",
        "properties": {
            "service_id": {
                "type": "string",
                "description": "Optional MCP service id. Omit to inspect all services.",
            }
        },
    }

    def __init__(self, context: MCPToolContext) -> None:
        self.context = context

    async def execute(
        self, service_id: Optional[str] = None, **kwargs: Any
    ) -> ToolExecutionResult:
        try:
            service_ids = (
                [service_id]
                if service_id
                else [service.id for service in self.context.services]
            )
            output = []
            for current_id in service_ids:
                clients = await self.context.connect(current_id)
                tools = [
                    {
                        "name": tool.original_name,
                        "description": tool.description or "",
                        "parameters": tool.parameters,
                    }
                    for tool in clients.tools
                    if tool.server_id == current_id
                ]
                service = self.context.find_service(current_id)
                output.append(
                    {
                        "id": current_id,
                        "description": service.description if service else "",
                        "tools": tools,
                    }
                )
            return self.success_response({"services": output})
        except Exception as exc:
            return self.fail_response(f"Failed to list MCP tools: {exc}")

    async def cleanup(self) -> None:
        """Close connections owned by the shared MCP context."""
        await self.context.close()

